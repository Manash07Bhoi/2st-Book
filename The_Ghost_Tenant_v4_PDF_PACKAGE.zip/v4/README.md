# The Ghost Tenant — v4 PDF package (design edition on the v3 text)

Contents
- out/The_Ghost_Tenant_v4_READER.pdf        cream paper, colour accents, cover, watermark key, bookmarks, tagged (224 pp)
- out/The_Ghost_Tenant_v4_PRINT_INTERIOR.pdf white paper, black/grey, no cover, no watermark (223 pp)
- build/build_pdf.py     rebuilds both PDFs from the v3 EPUB (`python3 build/build_pdf.py`), needs Playwright+Chromium, pypdf
- build/fonts/           Bitter static instances (SIL OFL 1.1) cut from the variable font; Crimson Text is read from the system font dir
- build/tools/measure_manuscript.py  the metric script used in the audits (shared so every party measures the same way)
- build/source/          v3 EPUB + v3 cover used as input

Text is NOT edited: only typography (apostrophes, dashes, rupee glyph, ordinal superscripts, scene-break ornament).
